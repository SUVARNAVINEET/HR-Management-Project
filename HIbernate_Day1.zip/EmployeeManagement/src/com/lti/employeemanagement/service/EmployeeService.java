package com.lti.employeemanagement.service;

import java.util.List;

import com.lti.employeemanagement.bean.EmployeeBean;

public interface EmployeeService {
	public String addEmployee(EmployeeBean employee);
	public EmployeeBean getEmployeeById(String userId);
	public List<EmployeeBean> getEmployees();
	public String deleteEmployee(String userId);
	public String updateEmployee(String userId);
}
