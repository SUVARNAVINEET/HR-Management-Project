package com.lti.employeemanagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lti.employeemanagement.bean.LoginBean;
import com.lti.employeemanagement.service.LoginService;
import com.lti.employeemanagement.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService service = new LoginServiceImpl();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession httpSession = null;
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");

		System.out.println("User name is: " + userName);
		System.out.println("Password is: " + password);

		LoginBean bean = new LoginBean();
		bean.setPassword(password);
		bean.setUserID(userName);

		if (service.validateUser(bean)) {
			if (service.getUserStatus(userName) == 0) {
				httpSession = request.getSession();
				System.out.println(httpSession.getId());
				service.updateUser(userName, 1);
				httpSession.setAttribute("userName", userName);
				if ("A".equals(service.getUserType(userName))) {
					RequestDispatcher dispatcher = request.getRequestDispatcher("adminHome.jsp");
					dispatcher.forward(request, response);
				} else {
					RequestDispatcher dispatcher = request.getRequestDispatcher("userHome.jsp");
					dispatcher.forward(request, response);
				}
			} else if (service.getUserStatus(userName) == 1) {
				service.updateUser(userName, 0);
			} else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("contactToAdmin.html");
				dispatcher.forward(request, response);
			}
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("home.html");
			dispatcher.forward(request, response);
		}
		/*
		 * if("admin".equals(userName) && "admin".equals(password)) {
		 * //response.sendRedirect("adminHome.html"); RequestDispatcher dispatcher =
		 * request.getRequestDispatcher("adminHome.html"); dispatcher.forward(request,
		 * response); } else{ //response.sendRedirect("home.html"); RequestDispatcher
		 * dispatcher = request.getRequestDispatcher("home.html");
		 * dispatcher.forward(request, response); }
		 */
	}

}
