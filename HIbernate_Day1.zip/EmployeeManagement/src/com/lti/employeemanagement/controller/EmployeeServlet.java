package com.lti.employeemanagement.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.employeemanagement.bean.EmployeeBean;
import com.lti.employeemanagement.service.EmployeeService;
import com.lti.employeemanagement.service.EmployeeServiceImpl;
import com.lti.employeemanagement.util.EmployeeUtils;

/**
 * Servlet implementation class EmployeeServlet
 */
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeBean bean = new EmployeeBean();
		Integer i = new Integer(request.getParameter("departmentId"));
		Float f = new Float(request.getParameter("salary"));
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String password = request.getParameter("password");
		String location = request.getParameter("location");
		String designation = request.getParameter("designation");
		int departmentId = i.intValue();
		float salary = f.floatValue();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date date_dob = null;
		java.util.Date date_doj=null;
		try {
			date_dob = sdf.parse(request.getParameter("dob"));
			date_doj = sdf.parse(request.getParameter("doj"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		java.sql.Date dob = new java.sql.Date(date_dob.getTime());
		java.sql.Date doj = new java.sql.Date(date_doj.getTime());
		bean.setFirstName(firstName);
		bean.setLastName(lastName);
		bean.setDesignation(designation);
		bean.setPassword(password);
		bean.setLocation(location);
		bean.setDepartmentId(departmentId);
		bean.setSalary(salary);
		bean.setDob(dob);
		bean.setDoj(doj);
		bean.setEmployeeId(EmployeeUtils.generateEmployeeId(bean.getFirstName()));
		System.out.println(bean);
		EmployeeService es = new EmployeeServiceImpl();
		String result = es.addEmployee(bean);
		System.out.println(result); 
	}
}
