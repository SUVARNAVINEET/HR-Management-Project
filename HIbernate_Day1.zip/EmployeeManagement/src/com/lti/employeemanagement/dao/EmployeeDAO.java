package com.lti.employeemanagement.dao;

import java.util.List;

import com.lti.employeemanagement.bean.EmployeeBean;

public interface EmployeeDAO {
	public String addEmployee(EmployeeBean employee);
	public EmployeeBean getEmployeeById(String userId);
	public List<EmployeeBean> getEmployees();
	public String deleteEmployee(String userId);
	public String updateEmployee(String userId);
}
