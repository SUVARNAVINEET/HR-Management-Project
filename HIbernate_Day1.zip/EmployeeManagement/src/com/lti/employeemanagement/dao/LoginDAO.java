package com.lti.employeemanagement.dao;

import com.lti.employeemanagement.bean.LoginBean;

public interface LoginDAO {
	
	public boolean validateUser(LoginBean bean);
	public String updateUser(String userId,int status);
	public int getuserStatus(String userId);
	public String getUserType(String userId);
	public String insertRecordLogin(LoginBean bean);
	public String deleteRecordLogin(String userId);
}
