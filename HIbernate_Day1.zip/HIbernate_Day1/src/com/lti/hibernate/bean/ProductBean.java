package com.lti.hibernate.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.Transient;
//import javax.persistence.Transient;

@Entity
public class ProductBean {
	private String name;
	@Id                   //for primary key                    
	private String id;
//	@Transient means do not consider in orm process like hidding
	private float price;
	private float quantity;
	//@Transient
	//private String password;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getQuantity() {
		return quantity;
	}

	public void setQuantity(float quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "ProductBean [name=" + name + ", id=" + id + ", price=" + price + ", quantity=" + quantity + "]";
	}

//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}

	
}
