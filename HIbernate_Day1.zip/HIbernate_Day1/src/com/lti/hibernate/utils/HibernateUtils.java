package com.lti.hibernate.utils;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtils {

	public static SessionFactory getSessionFactory() {

		return new AnnotationConfiguration().configure().buildSessionFactory();

	}

	public static void  closeSessionFactory(SessionFactory sessionFactory) {
		sessionFactory.close();

	}

}
