package com.lti.hibernate.main;


import java.util.Scanner;

import org.hibernate.SessionFactory;

import com.lti.hibernate.Service.ProductService;
import com.lti.hibernate.Service.ProductServiceImpl;
import com.lti.hibernate.bean.ProductBean;
import com.lti.hibernate.utils.HibernateUtils;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		HibernateUtils.closeSessionFactory(sessionFactory);
		ProductBean bean = new ProductBean();
		bean.setId("m102");
		//bean.setName("metal arm");
		//bean.setPrice(1200);
		//bean.setQuantity(2.0f);
		//bean.setPassword("buck");
		ProductService productService = new ProductServiceImpl();
		//productService.addproduct(bean);
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter ID: ");
		String id = scanner.next();
		ProductBean bean2 = productService.getProductById(id);
		System.out.println(bean2);
		scanner.close();
	}

}
