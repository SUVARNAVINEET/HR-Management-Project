package com.lti.hibernate.Service;

import java.util.List;

import com.lti.hibernate.bean.ProductBean;

public interface ProductService {
	
	public String addproduct(ProductBean product);
	public ProductBean getProductById(String id);
	public List<ProductBean> getProducts();
	public String deleteProduct(ProductBean bean);
	public String updateProduct(String id);

}
