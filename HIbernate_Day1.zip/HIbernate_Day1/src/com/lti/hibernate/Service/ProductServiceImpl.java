package com.lti.hibernate.Service;

import java.util.List;

import com.lti.hibernate.bean.ProductBean;
import com.lti.hibernate.dao.ProductDao;
import com.lti.hibernate.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{

	ProductDao productDao = new ProductDaoImpl();
	
	@Override
	public String addproduct(ProductBean product) {
		// TODO Auto-generated method stub
		return productDao.addproduct(product);
	}

	@Override
	public ProductBean getProductById(String id) {
		// TODO Auto-generated method stub
		return productDao.getProductById(id);
	}

	@Override
	public List<ProductBean> getProducts() {
		// TODO Auto-generated method stub
		return productDao.getProducts();
	}

	@Override
	public String deleteProduct(ProductBean bean) {
		// TODO Auto-generated method stub
		return productDao.deleteProduct(bean);
	}

	@Override
	public String updateProduct(String id) {
		// TODO Auto-generated method stub
		return productDao.updateProduct(id);
	}

}
