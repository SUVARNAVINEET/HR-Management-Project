package com.lti.hibernate.dao;

import java.util.List;

import com.lti.hibernate.bean.ProductBean;

public interface ProductDao {

	public String addproduct(ProductBean product);
	public ProductBean getProductById(String id);
	public List<ProductBean> getProducts();
	public String deleteProduct(ProductBean bean);
	public String updateProduct(String id);
	
}
