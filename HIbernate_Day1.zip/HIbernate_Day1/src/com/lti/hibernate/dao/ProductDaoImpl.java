package com.lti.hibernate.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lti.hibernate.bean.ProductBean;
import com.lti.hibernate.utils.HibernateUtils;

public class ProductDaoImpl implements ProductDao {
	private final SessionFactory sessionFactory = HibernateUtils.getSessionFactory();	
	
	@Override
	public String addproduct(ProductBean product) {
		Session session = sessionFactory.openSession();
		Transaction transaction= session.beginTransaction();
		session.persist(product);
		transaction.commit();
		session.close();
		return "Suddess!!";
	}

	@Override
	public ProductBean getProductById(String id) {
		Session session = sessionFactory.openSession();
		Transaction transaction= session.beginTransaction();
		ProductBean bean = (ProductBean) session.load(ProductBean.class, id);
		transaction.commit();
		//session.close();
		return bean;
	}

	@Override
	public List<ProductBean> getProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteProduct(ProductBean bean) {
		Session session = sessionFactory.openSession();
		Transaction transaction= session.beginTransaction();
		session.delete(bean);
		transaction.commit();
		session.close();
		return "Suddess!!";
	}

	@Override
	public String updateProduct(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
