package Details;

public class Customer {
	
	private  int custNo;
	private String custName ;
	private String custAdd ;
	private static int bill;
	static
	{
		bill=0;
	}
	public int getCustNo() {
		return custNo;
	}
	public void setCustNo(int num) {
		this.custNo = num;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String Name) {
		this.custName = Name;
	}
	public String getCustAdd() {
		return custAdd;
	}
	public void setCustAdd(String Add) {
		this.custAdd = Add;
	}
	
	public Customer() {
		this.custNo=10;
		this.custName="ram";
		this.custAdd="LTI";
		bill++;
	}
	public Customer(int num, String Name, String Add) {
		this.custNo=num;
		this.custName=Name;
		this.custAdd=Add;
		bill++;
	}
	public static void printBill() {
		System.out.println(bill);
		
	}
	
	
	
/*	public void Init(int custNo,String custoName,String custAdd)
	{
		this.custNo=custNo;
		this.custName=custoName;
		this.custAdd=custAdd;
	
	}
	public void display() {
		System.out.println(custNo);
		System.out.println(custName);
		System.out.println(custAdd);
	}
	*/
	
	
	
	
	
	
	/*public void inti() {
		this.custNo=1;
		this.custName="vineet";
		this.custAdd="Mhape";
	System.out.println(this.custNo+""+this.custName+""+this.custAdd);
	}*/
                
/*	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.custNo=123;
		customer.custName="vineet";
		customer.custAdd="MAHAPE";
		System.out.println(customer.custNo);
		System.out.println(customer.custName);
		System.out.println(customer.custAdd);
	}
*/
    	
    	
   
	

}
