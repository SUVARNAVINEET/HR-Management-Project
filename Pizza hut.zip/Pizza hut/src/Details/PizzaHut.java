package Details;

import java.util.Scanner;

public class PizzaHut {

	public static void main(String[] args) {
		
	@SuppressWarnings("resource")
	Scanner sc= new Scanner(System.in);
	
     CustomerReport result =new CustomerReport();
	
	
	for(int i=0;i<5;i++) {
	System.out.println("enter the number");
	int num =sc.nextInt();
	System.out.println("enter the name");
	String Name =sc.next();
	System.out.println("enter the address");
	String Add =sc.next();
 	result.custList[i]=new Customer(num,Name,Add);	//cr.custList[i]=new Customer(id,name,address);
 	 result.addCustomer(result.custList[i]);   
 	 }
	result.printList();
	}
	}


	//cr.addCustomer(cr.custList[i]);
 	//String res= result.addCustomer(cust);//result
// 	if("success".equals(res))
// 	{
// 		System.out.println("succesfulladdeed");
// 	}
// 	//printing part
// 	/*System.out.println("type the numberu want to founf");
// 	String find=sc.next();
// 	Customer cust2=new result.*/
// 	
// 	//default errro
// 		System.out.println("enter the correct choice");
//	}
	

  
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*Customer customer1=new Customer();
   customer1.Init(1, "vineet1", "mahape");
   customer1.display();
   
   Customer customer2=new Customer();
   customer2.Init(2, "vineet2", "Mahape2");
   customer2.display();
   Customer customer3=new Customer();
   customer3.Init(3, "vineet3", "Mhape3");
   customer3.display();*/
	/*Customer customer1=new Customer();
	customer1.setCustNo(1);
	System.out.println(customer1.getCustNo());
	customer1.setCustName("vineet1");
	System.out.println(customer1.getCustName());
	customer1.setCustAdd("Mahape1");
	System.out.println(customer1.getCustAdd());
	Customer customer2=new Customer();
	customer2.setCustNo(2);
	System.out.println(customer2.getCustNo());
	customer2.setCustName("vineet2");
	System.out.println(customer2.getCustName());
	customer2.setCustAdd("Mahape2");
	System.out.println(customer2.getCustAdd());*/
	
	
	
	
	
	
	
	
	
	
