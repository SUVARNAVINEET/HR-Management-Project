package Details;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class CustomerReport {
	
	
	int count=0;
         Customer[] custList=new Customer[5];
         public void addCustomer(Customer customer)
         {if (count< custList.length) {
        	 custList[count]=customer;  //custList[count++]=customer;pposiible
        	 count++;
        	 System.out.println("added");
         }
         else
         {
        	 
        	 System.out.println("fulll");
         }
        	
         }
         public void printList(){
        	 DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
        	 LocalDateTime now=LocalDateTime.now();
        	 if(custList[0].getCustName()==null)
        	 {System.out.println("no such name");
        	 }
        	 else
        	 {
        		 
        		 System.out.println("herre");
        		 for (Customer customer : custList) {
        			 Customer.printBill();
        			 System.out.println(""+ dtf.format(now)+"");
        			 System.out.println(customer.getCustName());
        			 System.out.println(customer.getCustNo());
        			 System.out.println(customer.getCustAdd());
       		 
        		 }
					
				}
       
}}
