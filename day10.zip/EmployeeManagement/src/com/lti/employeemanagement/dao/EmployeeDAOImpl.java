package com.lti.employeemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.employeemanagement.bean.EmployeeBean;
import com.lti.employeemanagement.bean.LoginBean;
import com.lti.employeemanagement.util.DBUtils;

public class EmployeeDAOImpl implements EmployeeDAO {

	LoginDAOImpl daoImpl = new LoginDAOImpl();

	@Override
	public String addEmployee(EmployeeBean employee) {
		String query = "insert into empl values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			//employee.setEmployeeId(EmployeeUtils.generateEmployeeId(employee.getFirstName()));
			preparedStatement.setString(1, employee.getEmployeeId());
			preparedStatement.setString(2, employee.getFirstName());
			preparedStatement.setString(3, employee.getLastName());
			preparedStatement.setDate(4, employee.getDob());
			preparedStatement.setDate(5, employee.getDoj());
			preparedStatement.setString(6, employee.getDesignation());
			preparedStatement.setFloat(7, employee.getSalary());
			preparedStatement.setInt(8, employee.getDepartmentId());
			preparedStatement.setString(9, employee.getLocation());
			int result = preparedStatement.executeUpdate();
			if (result == 1) {
				LoginBean bean = new LoginBean();
				bean.setPassword(employee.getPassword());
				bean.setUserID(employee.getEmployeeId());
				String s = daoImpl.insertRecordLogin(bean);
				connection.commit();
				return "Inserted into Employee!" + " " + s;
			} else {
				return "ELSE:Failed to insert!";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "CATCH:Failed to insert";
		} finally {
			DBUtils.close(connection);
		}
		// return "LAST:Failed to insert!";
	}

	@Override
	public EmployeeBean getEmployeeById(String userId) {
		String query = "select * from empl where employeeid = ?";
		String query1 = "select password from login where userid= ?";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement1 = connection.prepareStatement(query1);
			preparedStatement.setString(1, userId);
			preparedStatement1.setString(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();
			ResultSet resultSet1 = preparedStatement1.executeQuery();
			if(resultSet.next()) {
				if(resultSet1.next()) {
					EmployeeBean bean = new EmployeeBean();
					bean.setPassword(resultSet1.getString(1));
					bean.setEmployeeId(resultSet.getString(1));
					bean.setFirstName(resultSet.getString(2));
					bean.setLastName(resultSet.getString(3));
					bean.setDob(resultSet.getDate(4));
					bean.setDoj(resultSet.getDate(5));
					bean.setDesignation(resultSet.getString(6));
					bean.setSalary(resultSet.getFloat(7));
					bean.setDepartmentId(resultSet.getInt(8));
					bean.setLocation(resultSet.getString(9));
					return bean;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection);
		}
		return null;
	}

	@Override
	public List<EmployeeBean> getEmployees() {
		String query = "select * from empl";
		Connection connection = DBUtils.getConnection();
		PreparedStatement  preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			ArrayList<EmployeeBean> employees = new ArrayList<>();
			while(resultSet.next()) {
				EmployeeBean bean = new EmployeeBean();
				bean.setPassword(resultSet.getString(1));
				bean.setEmployeeId(resultSet.getString(1));
				bean.setFirstName(resultSet.getString(2));
				bean.setLastName(resultSet.getString(3));
				bean.setDob(resultSet.getDate(4));
				bean.setDoj(resultSet.getDate(5));
				bean.setDesignation(resultSet.getString(6));
				bean.setSalary(resultSet.getFloat(7));
				bean.setDepartmentId(resultSet.getInt(8));
				bean.setLocation(resultSet.getString(9));
				employees.add(bean);
			}
			System.out.println(employees);
			return employees;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String deleteEmployee(String userId) {
		String query = "delete from empl where employeeid=?";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);
			int result = preparedStatement.executeUpdate();
			if (result == 1) {
				String s = daoImpl.deleteRecordLogin(userId);
				connection.commit();
				return s + " Deleted Succesfully from empl";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "CATCH:Failed to Delete from empl!";

		} finally {
			DBUtils.close(connection);
		}

		return "LAST:Failed to Delete from empl!";
	}

	@Override
	public String updateEmployee(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
