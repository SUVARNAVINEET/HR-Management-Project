package com.lti.employeemanagement.service;

import java.util.List;

import com.lti.employeemanagement.bean.EmployeeBean;
import com.lti.employeemanagement.dao.EmployeeDAO;
import com.lti.employeemanagement.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService{
	
	private EmployeeDAO employeedao = new EmployeeDAOImpl();
;
	@Override
	public String addEmployee(EmployeeBean employee) {
		// TODO Auto-generated method stub
		return employeedao.addEmployee(employee);
	}

	@Override
	public EmployeeBean getEmployeeById(String userId) {
		// TODO Auto-generated method stub
		return employeedao.getEmployeeById(userId);
	}

	@Override
	public List<EmployeeBean> getEmployees() {
		// TODO Auto-generated method stub
		return employeedao.getEmployees();
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		return employeedao.deleteEmployee(userId);
	}

	@Override
	public String updateEmployee(String userId) {
		// TODO Auto-generated method stub
		return employeedao.updateEmployee(userId);
	}

}
