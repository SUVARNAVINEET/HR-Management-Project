package com.lti.day1.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

import com.lti.day1.bean.Employee;

public class EmployeeServiceImp implements EmployeeService {

	private ArrayList<Employee> employees = new ArrayList<>();

	@Override
	public String addEmployee(Employee employee) {
		try {
			employees.add(employee);
		} catch (Exception e) {
			System.out.println("Phailed!");
		}
		return "Success!";
	}

	@Override
	public Employee getEmployeeById(String id) {

		/*
		 * for (Employee employee : employees) if (id.equals(employee.getEmployeeId()))
		 * return employee;
		 */

		/*
		 * ListIterator<Employee> iterator = employees.listIterator();
		 * while(iterator.hasNext()) { Employee employee = iterator.next();
		 * if(id.equals(employee.getEmployeeId())) return employee; }
		 */

		/*
		 * for (Iterator<Employee> iterator = employees.iterator(); iterator.hasNext();)
		 * { Employee employee = (Employee) iterator.next(); if
		 * (id.equals(employee.getEmployeeId())) return employee; }
		 */

		employees.forEach(emp1 -> {
			if (id.equals(emp1.getEmployeeId())) {
				System.out.println("Record Found!");
			} else
				System.out.println("Not Found!");
		});
		return null;

		/*
		 * return employees.stream().filter(emp1 -> id.equals(emp1.getEmployeeId()))
		 * .collect(Collectors.toList()).get(0);
		 */
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}
}
