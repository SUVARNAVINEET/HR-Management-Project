package com.lti.day1.service;

import java.util.Scanner;

import com.lti.day1.bean.Employee;

public class Test {

	public static void main(String[] args) {
		EmployeeServiceImp esi = new EmployeeServiceImp();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int status = 1;
		String eid;
		while (status == 1) {
			System.out.println("Enter your choice: ");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Enter Employee ID: ");
				eid = sc.next();
				System.out.println("Enter Employee Name: ");
				String ename = sc.next();
				System.out.println("Enter Employee Salary: ");
				float esal = sc.nextFloat();
				Employee emp = new Employee(eid, ename, esal);
				String res = esi.addEmployee(emp);
				System.out.println(res);
				break;
			case 2:
				System.out.println("Enter Employee ID to search");
				eid = sc.next();
				Employee emp1 = esi.getEmployeeById(eid);
				if(emp1 == null)
					System.out.println("Not found!");
				else
					System.out.println(emp1.getEmployeeName());
				break;
			/*case 3:
				System.out.println("Enter Employee ID to Delete");
				eid = sc.next();
				String result = esi.delEmployeeById(eid);
				System.out.println(result);
				break;*/
			default:
				System.out.println("Wrong Choice");
			}
			System.out.println("Continue?(0/1): ");
			status = sc.nextInt();
		}
		System.out.println("Bubyee");
	}
}
