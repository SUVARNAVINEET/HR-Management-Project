package com.lti.day1.bean;

public class Employee {

	/*
	 * public Employee(String employeeId, String employeeName, float employeeSalary)
	 * { this.employeeId = employeeId; this.employeeName = employeeName;
	 * this.employeeSalary = employeeSalary; }
	 */
	/*
	 * public Employee() {
	 * 
	 * }
	 */
	public Employee() {
		System.out.println("without parameter");

	}
    
	public Employee(String s1, String s2, float s3) {
		//System.out.println("with parameter in base");
		this.employeeId = s1;
		this.employeeName = s2;
		this.employeeSalary = s3;
	}

	String employeeId;
	private String employeeName;
	private float employeeSalary;

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public float getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	protected float calculateSalary() {
		float net_sal=0;
		float hra=this.employeeSalary*0.1f;
		float ta= this.employeeSalary*0.1f;
		float da= this.employeeSalary*0.1f;
		net_sal=hra+ta+da+this.employeeSalary;
		return net_sal;
	}

	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((employeeId == null) ? 0 : employeeId.hashCode());
		result = prime * result + ((employeeName == null) ? 0 : employeeName.hashCode());
		result = prime * result + Float.floatToIntBits(employeeSalary);
		return result;
	}*/

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeId == null) {
			if (other.employeeId != null)
				return false;
		} else if (!employeeId.equals(other.employeeId))
			return false;
		if (employeeName == null) {
			if (other.employeeName != null)
				return false;
		} else if (!employeeName.equals(other.employeeName))
			return false;
		if (Float.floatToIntBits(employeeSalary) != Float.floatToIntBits(other.employeeSalary))
			return false;
		return true;
	}

	/*@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + "]";
	}  */
	
	
}