package com.lti.day1.bean;

public class Employeetest {

	public static void display(Employee employee) {
		float result=employee.calculateSalary();
		Employee e = new Employee();
		System.out.println(result);
		
	}
	public static void main(String[] args) {
		//Employeetest.display(new Manager());
		Employee emp1 = new Employee("101", "Kaam", 45.6f);
		Employee emp2 = new Employee("101", "Kaam", 45.6f);
		//Employee e3=emp2;
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		//System.out.println(e3.hashCode());
		System.out.println(emp2.equals(emp1));
		System.out.println(emp2.toString());
		System.out.println(emp2);
	}
}
	
