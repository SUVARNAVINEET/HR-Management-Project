package com.lti.day1.bean;

public class AccountManager extends Manager {
//	public AccountManager(float basic) {
//		
//		this.basic = basic;
//	}
//	
	public float basic;
	public static void main(String[] args) {
		AccountManager accountManager = new AccountManager();
		accountManager.setEmployeeId("kaka");
		System.out.println(accountManager.getEmployeeId());
	}
}
