package com.lti.day1.bean;

public class Manager extends Employee{
	private float projectAllowance;
//
//	public Manager(){
//		super("","","");
//		
//	}
   
//	public Manager(String s1, String s2, String s3) {
//		this.setEmployeeId(s1);
//		
//	}
//	public Manager(String s1,String s2, String s3,float p) {
//		this (s1,s2,s3);
//		this.projectAllowance= 10.0f;
//	}

	public float getProjectAllowance() {
		return projectAllowance;
	}

	public void setProjectAllowance(float projectAllowance) {
		this.projectAllowance = projectAllowance;
	}
	public static void main(String[] args) {
//		Manager manager= new Manager("Hello", "This", "World");
//		manager.setEmployeeId("1235");
//		manager.setEmployeeName("ramu");
//		manager.setEmployeeSalary(250.0f);
//		manager.setProjectAllowance(25.0f);
//		System.out.println(manager.getEmployeeId());
//		System.out.println(manager.getEmployeeName());		
//		System.out.println(manager.getEmployeeSalary());
//		System.out.println(manager.getProjectAllowance());
		  Employee emp =new Manager();
		 emp.setEmployeeSalary(20000.0f);
		emp.setEmployeeId("");
		System.out.println(emp.calculateSalary());
		
		
		
		
	}

	@Override
	 protected float calculateSalary() {
		// TODO Auto-generated method stub
		float net_sal=super.calculateSalary()+this.projectAllowance;
		return net_sal;
	}

}
