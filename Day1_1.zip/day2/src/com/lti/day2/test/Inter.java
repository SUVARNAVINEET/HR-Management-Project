package com.lti.day2.test;

public interface Inter {
	public void display();

	 default public  void show()
	{
		System.out.println("heyloo");
	}
		

}
