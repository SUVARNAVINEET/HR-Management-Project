package com.lti.day2.test;

public class Interface implements Inter{
	
	@Override
	public void display() {
		System.out.println("hey its 6.00!");
		
	}

	public static void main(String[] args) {
	   Interface i=new Interface();
	   i.show();
	   i.display();
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		Inter.super.show();
	}
	

}
