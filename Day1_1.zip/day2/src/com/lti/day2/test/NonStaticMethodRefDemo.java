package com.lti.day2.test;

import java.util.function.BiFunction;

public class NonStaticMethodRefDemo {

	public float add(float a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
//		BiFunction<Float,Integer,Float> biFunction = StaticMethodRefDemo::add;
//		float result = biFunction.apply(10.50f, 30);
//		System.out.println(result);
//		float a = StaticMethodRefDemo.add(100.0f, 200);
//		System.out.println(a);
		//create the object
		NonStaticMethodRefDemo demo =new NonStaticMethodRefDemo();
		BiFunction<Float, Integer, Float> bifunction=demo::add;
		float result =bifunction.apply(20.5f, 40);
	System.out.println(result);
	}

}