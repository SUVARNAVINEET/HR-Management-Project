package com.lti.day2.test;

public abstract class Abstract {
//	private String name;
	public Abstract() {

	}

	public void showSample(int a, int b) {
		System.out.println("hellow from the show");
	}

	public static void display() {
		System.out.println("hello from shree");
	}

	

}

