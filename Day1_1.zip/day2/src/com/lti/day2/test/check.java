package com.lti.day2.test;

public class check {
	public static void m1() {
		System.out.println("yes");
	}
}
