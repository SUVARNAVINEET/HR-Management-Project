package com.lti.day2.test;

import java.util.ArrayList;

public class test {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		//check.m1();
		list.add("Ram");
		list.add("Shyam");
		list.add("Ghanshyan");
		System.out.println("In Java 7!");
		for (String string : list)
			System.out.println(string);
		System.out.println("In Java 8!");
		list.forEach(System.out::println);
		System.out.println("I'm Done!");
	}
}
