package com.lti.day2.test;

public class Abtest {
	public static void main(String[] args) {
		Abstract demo=null;
	     demo =new Derived();
		Derived derived=(Derived)demo;
		float f = 0.9f;
		
		int i = (int)f;
		derived.sample();
	}	
}
