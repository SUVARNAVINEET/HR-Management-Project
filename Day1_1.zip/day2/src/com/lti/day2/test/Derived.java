package com.lti.day2.test;

public class Derived extends Abstract{
public void test()
{
System.out.println("hey test");		
		
	}
public void sample()
{
System.out.println("hey sample");		
		
	}

}
