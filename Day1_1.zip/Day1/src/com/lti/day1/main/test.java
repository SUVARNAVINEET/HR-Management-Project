package com.lti.day1.main;

import com.lti.day1.bean.Employee;

public class test {

	public static void main(String[] args) {
		Employee emp1 = Employee.getInstance();
		System.out.println(emp1.getEmployeeId());
		
		emp1.setEmployeeName("Ram");
		String s = emp1.getEmployeeName();
		System.out.println(emp1.getEmployeeName());
		System.out.println(s);
		
		Employee emp2 = Employee.getInstance();
		System.out.println(emp2.getEmployeeName());
	}
}
