package com.lti.day1.bean;

public class Employee {
	
	private Employee(String employeeId, String employeeName, String deptName) {
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.deptName = deptName;
	}
	private String employeeId;
	private String employeeName;
	private String deptName;
	private float employeeSalary;
	private int deptId;
	private static Employee employee;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public float getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public static Employee getInstance() {
		if (employee == null) {
			employee = new Employee("AB101", "Rik", "CMPN");
			return employee;
		}
		else
		{
			return employee;
		}
	}	
}