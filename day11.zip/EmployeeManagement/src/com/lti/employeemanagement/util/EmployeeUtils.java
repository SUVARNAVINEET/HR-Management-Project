package com.lti.employeemanagement.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeUtils {
	public static String generateEmployeeId(String firstName) {
		String query = "select emp_seq.nextval as id from dual";
		Connection connection = DBUtils.getConnection();
		ResultSet resultSet = null;
		String res = null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {//?
				 res = resultSet.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Inside catch: generateEmployeeId()");
			return null;
		} finally {
			DBUtils.close(connection);
		}
		return firstName.substring(0, 2).concat(res);
	}
}
