package com.lti.employeemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.lti.employeemanagement.bean.LoginBean;
import com.lti.employeemanagement.util.DBUtils;

public class LoginDAOImpl implements LoginDAO {

	@Override
	public boolean validateUser(LoginBean bean) {
		// how can i get a connection ,get connection from dbutil class
		PreparedStatement preparedStatement = null;
		Connection connection = DBUtils.getConnection();
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement("select * from login where userid=? and password=?");
			preparedStatement.setString(1, bean.getUserID());
			preparedStatement.setString(2, bean.getPassword());
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			DBUtils.close(connection);
		}
		return false;
	}

	@Override
	public String updateUser(String userID, int status) {
		String query = "update login set userstatus = ? where userid = ?";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, status);
			preparedStatement.setString(2, userID);
			int result = preparedStatement.executeUpdate();
			if (result == 1) {
				connection.commit();
				return "Success!";
			} else {
				return "Failed to update!";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtils.close(connection);
		}
		return "Failed to update!";
	}

	@Override
	public int getuserStatus(String userId) {

		String query = "select userstatus from login where userid=?";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId); // quetsmark seq
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getInt(1); // colum seq as per the query

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection);
		}
		return 0;
	}

	@Override
	public String getUserType(String userId) {
		String query = "select usertype from login where userid=?";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtils.close(connection);
		}
		return null;
	}

	@Override
	public String insertRecordLogin(LoginBean bean) {
		String query = "insert into login values(?, ?, 'U', 0)";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bean.getUserID());
			preparedStatement.setString(2, bean.getPassword());
			int result = preparedStatement.executeUpdate();
			if (result == 1) {
				connection.commit();
				return "Inserted into Login!";
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failed to insert into Login";
		} finally {
			DBUtils.close(connection);
		}
		return "Failed to insert into Login";
	}

	@Override
	public String deleteRecordLogin(String userId) {
		String query = "delete from login where userid=?";
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);
			int result = preparedStatement.executeUpdate();
			if (result == 1) {
				connection.commit();
				return "Deleted successfully from Login!";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "CATCH:Failed to delete from Login!";
		} finally {
			DBUtils.close(connection);
		}
		return "LAST:Failed to delete from Login!";
	}

}
